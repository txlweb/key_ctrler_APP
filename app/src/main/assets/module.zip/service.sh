#!/system/bin/sh

# KCTRL Service Script
# 设置可执行文件权限
chmod 777 /data/adb/modules/kctrl/kctrl
chmod 777 /data/adb/modules/kctrl/kfind
chmod 777 /data/adb/modules/kctrl/klaunch
chmod 777 /data/adb/modules/kctrl/scripts/*.sh

# 删除旧的进程ID文件
rm -f /data/adb/modules/kctrl/mpid.txt

# 使用klaunch启动kctrl
/data/adb/modules/kctrl/klaunch /data/adb/modules/kctrl/kctrl

# 记录启动日志
echo "KCTRL service started at $(date)" >> /data/adb/modules/kctrl/service.log